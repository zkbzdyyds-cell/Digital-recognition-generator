﻿HTML Build02.3 / Structure50 / 固定Focus。
每图包含：HTML02.2基线，A Thin+Off，B Medium+Pool，C Thick+Custom MELANCHOLY，D三次Shuffle。
comparison.png为四宫格对照，标题在实际导出图之外。
12张02.3 PNG均来自真实下载按钮，尺寸与canvas一致；baseline PNG用于对照。
