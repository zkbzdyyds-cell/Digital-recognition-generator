﻿IMAGE OBSERVER · BUILD 02.3
HTML + CSS + JavaScript / Canvas 正式运行源码包

1. 全部解压此ZIP。
2. 用Chrome或Edge打开 Image-Observer-Build-02.3.html。
3. 顶部必须显示 IMAGE OBSERVER · BUILD 02.3。

该HTML已经包含完整CSS和JavaScript源代码，不需要安装Python、Node、Gradio或任何依赖。
不需要启动服务；本轮尚未部署网站。图片只在当前浏览器处理，不调用外部API。

上传JPG/PNG，Structure可调0–100；点击原图设置Focus，Reset恢复自动。
Stroke Width：Thin 1px、Medium 2px（默认）、Thick 4px。
Labels：Off、Emotion Pool（默认）、Custom Text。
Emotion Pool模式点击Shuffle Word换词；每张图主框/中框同词，微型框无文字。
Custom Text自动大写，最多32字符。切回Pool恢复此前词。
线宽、文字、Shuffle只重绘Overlay，不重新检测或改变框坐标。
点击“下载PNG”保存实际输出图片；最长边不超过1600px，保持完整比例。

两分钟验收：上传图片→Structure50→点击Focus→Thin+Off→Medium+Pool→Thick+Custom MELANCHOLY→回Pool连续换词3次→下载PNG。

本包只含HTML02.3、此说明和版本清单，没有旧HTML02.2、Python或BAT。
GitHub文件页会显示源码；下载完整HTML文件后再打开，不要把代码复制到记事本变成.txt。
测试使用Chromium和断网文档；当前执行环境禁止file://自动导航，未宣称Windows双击实机测试通过。
本地字体、浏览器解码可能有像素差异；超大原图可能受设备内存限制。

源仓库：https://github.com/zkbzdyyds-cell/Digital-recognition-generator/tree/build-02-3
仅完成Build02.3，等待验收；未开发Build02.4、未部署GitHub Pages。
